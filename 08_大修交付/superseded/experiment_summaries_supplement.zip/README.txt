Supplementary experiment summaries for COMNET-D-26-03761

cross_version_condition_summary.csv contains the 48 E1/E2 implementation-condition means (five runs per condition). flow2_share_mean and jain_mean are means of run-level metrics, not metrics computed from averaged rates. E2 flow1 is BBR and flow2 is CUBIC; BBR share is 1-flow2_share_mean.

E3 condition_summary.csv records the equal-RTT extension. Physical buffer ratios for the 50-Mbps cases differ from the frozen labels; manuscript Table 10 reports corrected physical target ratios without rewriting the original predictions.

Receiver summaries use full-run measurements. The declared warmup is not excluded in primary results. Early RTT probes and pre-completion queue snapshots do not establish simultaneous post-warmup delay or full-run drop counts. Kernel environments differ across implementations; manifests do not establish identical builds or isolate version effects.

This supplement contains summary data and analysis provenance, not the complete per-run raw-log archive. The original raw logs remain in the project repository. The retained raw records include 340 runs; these selected files support the E1/E2/E3 summaries. No new experimental runs are claimed.
