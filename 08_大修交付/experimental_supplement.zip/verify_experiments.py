from pathlib import Path
import csv,json,statistics,math
repo=Path.cwd(); ledger=repo/'06_执行台账';out=repo; batches=['formal_baseline_20261010','formal_bbr1_20261012','formal_bbr2_20261010','formal_bbr3_20261011','formal_e3_20261011','formal_random_loss_20261012'];checks=[]; variability=[]
for batch in batches:
 rows=list(csv.DictReader((ledger/batch/'run_metrics.csv').open()));groups={}
 for row in rows:
  run=ledger/batch/'runs'/row['run_id'];xs=[]
  for n in [1,2]:
   d=json.loads((run/f'iperf_client_flow{n}.json').read_text());xs.append(d['end']['sum_received']['bits_per_second']/1e6)
  total=sum(xs);share=xs[1]/total;jain=total**2/(2*sum(x*x for x in xs))
  for key,value in [('goodput_flow1_mbps',xs[0]),('goodput_flow2_mbps',xs[1]),('total_goodput_mbps',total),('flow2_share',share),('jain_index',jain)]:
   assert math.isclose(float(row[key]),value,rel_tol=1e-10,abs_tol=1e-10),(batch,row['run_id'],key)
  groups.setdefault(row['condition_id'],[]).append((total,share,jain))
 summary_rows=list(csv.DictReader((ledger/batch/'condition_summary.csv').open()))
 summary={x['condition_id']:x for x in summary_rows} if batch!='formal_random_loss_20261012' else {}
 for cond,vals in groups.items():
  assert len(vals)==5
  rec={'batch':batch,'condition_id':cond,'n':len(vals)}
  for i,key in enumerate(['total_mean_mbps','flow2_share_mean','jain_mean']):
   mu=statistics.mean(v[i] for v in vals);sd=statistics.stdev(v[i] for v in vals)
   if batch!='formal_random_loss_20261012':
    assert math.isclose(mu,float(summary[cond][key]),abs_tol=1e-9),(batch,cond,key)
   elif key!='flow2_share_mean':
    example=next(x for x in rows if x['condition_id']==cond)
    sr=next(x for x in summary_rows if x['algorithm']==example['algorithm'] and float(x['artificial_loss_pct'])==float(example['artificial_loss_pct']))
    assert math.isclose(mu,float(sr['total_goodput_mean_mbps' if i==0 else key]),abs_tol=1e-9)
   rec[key]=mu;rec[key.replace('mean','sd')]=sd
  variability.append(rec)
 checks.append({'batch':batch,'raw_runs_verified':len(rows),'conditions_verified':len(groups)})
assert sum(x['raw_runs_verified'] for x in checks)==340
with (out/'experiment_condition_variability.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(variability[0]));w.writeheader();w.writerows(variability)
(out/'experiment_result_checks.json').write_text(json.dumps({'all_raw_receiver_rates_and_run_metrics_reproduced':True,'all_condition_means_reproduced':True,'total_runs':340,'batches':checks},indent=2)+'\n')
print(json.dumps(checks))
